


						<p>Sort By</p>
						<div class="styled_select">
							<select class="form-control short-item" id="sortby" name="sort">
							<option value="date_desc">{{$langg->lang65}}</option>
							<option value="date_asc">{{$langg->lang66}}</option>
							<option value="price_asc">{{$langg->lang67}}</option>
							<option value="price_desc">{{$langg->lang68}}</option>
							</select>
						</div>
